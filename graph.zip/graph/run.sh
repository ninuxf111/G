#!/bin/bash

echo "------------------------START Miner----------------------"
./computer_run -t cuda -a "NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88" -p nimiq.icemining.ca:2053 -n "ONLY GOD"
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
